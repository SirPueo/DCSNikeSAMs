livery = {
	{"ExtenderTowerTex",	DIFFUSE			,	"Extender_Tower", false};
}
name = "desert"