livery = {
	{"ExtenderTowerTex",	DIFFUSE			,	"Extender_Tower", false};
}
name = "dark green"