livery = {
	{"StandAloneLauncher",	DIFFUSE			,	"LN_Texture", false};
}
name = "green"