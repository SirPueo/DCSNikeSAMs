livery = {
	{"BCT_Texture",	DIFFUSE			,	"BCT_desert", false};
}
name = "desert"