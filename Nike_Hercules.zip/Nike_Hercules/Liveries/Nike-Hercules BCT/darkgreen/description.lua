livery = {
	{"BCT_Texture",	DIFFUSE			,	"BCT_DarkGreen", false};
}
name = "darkgreen"