livery = {
	{"BCT_Texture",	DIFFUSE			,	"BCT_Texture", false};
}
name = "green"