livery = {
	{"TRR_Base",	DIFFUSE			,	"TRR_Base_DarkGreen", false};
	{"TRR_Swivel",	DIFFUSE			,	"TRRSwivel_DarkGreen", false};
	{"TRR_Sensor",	DIFFUSE			,	"TRR_Sensor_DarkGreen", false};
}
name = "dark green"