livery = {
	{"TRR_Base",	DIFFUSE			,	"TRR_Base", false};
	{"TRR_Swivel",	DIFFUSE			,	"TRRSwivel_Texture", false};
	{"TRR_Sensor",	DIFFUSE			,	"TRR_Sensor", false};
}
name = "desert"