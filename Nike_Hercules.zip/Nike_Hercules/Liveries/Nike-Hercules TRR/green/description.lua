livery = {
	{"TRR_Base",	DIFFUSE			,	"TRRBase_Texture", false};
	{"TRR_Swivel",	DIFFUSE			,	"TRRPivot_Texture", false};
	{"TRR_Sensor",	DIFFUSE			,	"TRR_Texture", false};
}
name = "green"