livery = {
	{"Booster14C_1",	DIFFUSE			,	"Booster_C_1", false};
	{"MSL_14C_1",	DIFFUSE			,	"MIM14C_1", false};
}
name = "green"