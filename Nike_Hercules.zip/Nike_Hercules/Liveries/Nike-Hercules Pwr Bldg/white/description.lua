livery = {
	{"PwrBldg",	DIFFUSE			,	"PWR_texture", false};
}
name = "white"