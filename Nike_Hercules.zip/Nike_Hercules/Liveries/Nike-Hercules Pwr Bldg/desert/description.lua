livery = {
	{"PwrBldg",	DIFFUSE			,	"PWR_Texture", false};
}
name = "desert"