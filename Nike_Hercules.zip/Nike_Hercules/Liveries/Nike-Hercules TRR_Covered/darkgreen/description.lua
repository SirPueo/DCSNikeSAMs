livery = {
	{"MTR_Base",	DIFFUSE			,	"TRR_Base_DarkGreen", false};
	{"MTR_Swivel",	DIFFUSE			,	"TRRSwivel_DarkGreen", false};
	{"RadarCover",	DIFFUSE			,	"radarCover", false};
	{"MTR_Sensor",	DIFFUSE			,	"TRR_Sensor_DarkGreen", false};
}
name = "dark green"