livery = {
	{"MTR_Base",	DIFFUSE			,	"TRR_Base", false};
	{"MTR_Swivel",	DIFFUSE			,	"TRRSwivel_Texture", false};
	{"RadarCover",	DIFFUSE			,	"radarCover", false};
	{"MTR_Sensor",	DIFFUSE			,	"TRR_Sensor", false};
}
name = "desert"