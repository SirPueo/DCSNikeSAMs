livery = {
	{"MTR_Base",	DIFFUSE			,	"TRRBase_Texture", false};
	{"MTR_Swivel",	DIFFUSE			,	"TRRPivot_Texture", false};
	{"RadarCover",	DIFFUSE			,	"radarCover", false};
	{"MTR_Sensor",	DIFFUSE			,	"TRR_Texture", false};
}
name = "green"