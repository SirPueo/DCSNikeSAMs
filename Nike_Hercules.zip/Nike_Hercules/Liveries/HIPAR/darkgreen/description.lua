livery = {
	{"HIPAR_Mat",	DIFFUSE			,	"HIPAR_DarkGreen", false};
}
name = "darkgreen"