livery = {
	{"HIPAR_Mat",	DIFFUSE			,	"HIPAR_Texture_white", false};
}
name = "white"