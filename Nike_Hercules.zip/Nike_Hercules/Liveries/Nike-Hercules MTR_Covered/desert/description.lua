livery = {
	{"MTR_Sensor",	DIFFUSE			,	"MTR_TTR_Texture", false};
	{"MTR_Base",	DIFFUSE			,	"RadarBase_Texture", false};
	{"RadarCover",	DIFFUSE			,	"radarCover", false};
	{"MTR_Swivel",	DIFFUSE			,	"RadarPivot_Texture", false};
}
name = "desert"