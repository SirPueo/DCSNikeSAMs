livery = {
	{"RCT",	DIFFUSE			,	"RCT_desert", false};
}
name = "desert"