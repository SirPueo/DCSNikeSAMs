livery = {
	{"RCT",	DIFFUSE			,	"RCT_Texture", false};
}
name = "dark green"