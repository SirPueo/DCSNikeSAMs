livery = {
	{"Booster14B_2",	DIFFUSE			,	"Booster_B_2", false};
	{"MSL_14B_2",	DIFFUSE			,	"MIM14B_2", false};
}
name = "GermanNike"