livery = {
	{"LOPAR_Base",	DIFFUSE			,	"LoparBase_DarkGreen", false};
	{"LOPAR_Dome",	DIFFUSE			,	"LoparAnt_DarkGreen", false};
}
name = "dark green"