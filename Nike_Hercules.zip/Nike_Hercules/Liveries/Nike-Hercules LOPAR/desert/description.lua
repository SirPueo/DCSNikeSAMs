livery = {
	{"LOPAR_Base",	DIFFUSE			,	"LoparBase_Texture", false};
	{"LOPAR_Dome",	DIFFUSE			,	"LoparAnt_Texture", false};
}
name = "desert"