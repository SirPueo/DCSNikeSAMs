livery = {
	{"Booster14C_2",	DIFFUSE			,	"Booster_C_2", false};
	{"MSL_14C_2",	DIFFUSE			,	"MIM14C_2", false};
}
name = "green_NL"