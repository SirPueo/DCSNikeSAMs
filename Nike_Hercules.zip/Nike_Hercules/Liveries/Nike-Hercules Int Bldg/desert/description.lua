livery = {
	{"IntBldg",	DIFFUSE			,	"InterConnBldg", false};
}
name = "desert"