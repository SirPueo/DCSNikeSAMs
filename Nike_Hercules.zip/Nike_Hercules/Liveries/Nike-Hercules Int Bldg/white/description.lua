livery = {
	{"IntBldg",	DIFFUSE			,	"ICB_Texture", false};
}
name = "white"