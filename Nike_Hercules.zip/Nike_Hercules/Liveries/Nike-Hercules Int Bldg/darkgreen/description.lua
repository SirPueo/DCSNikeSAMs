livery = {
	{"IntBldg",	DIFFUSE			,	"InterConnBldg", false};
}
name = "dark green"