livery = {
	{"MTR_Sensor",	DIFFUSE			,	"MTR_TTR_DarkGreen", false};
	{"MTR_Base",	DIFFUSE			,	"RadarBase_DarkGreen", false};
	{"MTR_Swivel",	DIFFUSE			,	"RadarPivot_DarkGreen", false};
}
name = "dark green"