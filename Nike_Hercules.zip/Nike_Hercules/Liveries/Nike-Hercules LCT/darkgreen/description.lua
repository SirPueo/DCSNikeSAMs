livery = {
	{"LCT",	DIFFUSE			,	"LCT_Texture", false};
}
name = "dark green"