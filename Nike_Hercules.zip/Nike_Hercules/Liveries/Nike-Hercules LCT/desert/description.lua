livery = {
	{"LCT",	DIFFUSE			,	"LCT_Texture", false};
}
name = "desert"